<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paths extends Model
{
    public $table="paths";
}
